/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.io.*;

import org.apache.spark.api.java.*;
import org.apache.spark.api.java.function.*;
import org.apache.spark.SparkConf;

import scala.Tuple2;

public class SumOfPrimes {
	@SuppressWarnings("serial")
	public static void main(String[] args) {

		SparkConf conf = new SparkConf().setAppName("Sum of Squares")
				.setMaster("local");
		JavaSparkContext sc = new JavaSparkContext(conf);
		final int n = Integer.parseInt(args[0]);
		System.out.println(n);
		
		List<Integer> anArray = (List<Integer>) new ArrayList<Integer>(n+1);
		
		for (int i = 1; i <= n; i++) {
			anArray.add(i);
		}
		

		//List<Integer> data = Arrays.asList(anArray);
		//List<Integer> data = Arrays.asList(1,2,3,4,5);
		// Create RDD
		@SuppressWarnings("serial")
		//JavaRDD<Integer> baseRDD = sc.parallelize(data);
		JavaRDD<Integer> baseRDD = sc.parallelize(anArray);
	//	System.out.println(baseRDD.take(2));
		baseRDD.take(2);

		// Transformation - Compute Squares
		@SuppressWarnings("serial")
		JavaRDD<Integer> primes = baseRDD.filter(new Function<Integer, Boolean>() {
			  public Boolean call(Integer s) { int i =0;
			  								   int num =0;
			  								   boolean flag =  false;
			  								   for (i = 1; i <= n; i++) 
			  								   { 
			  									   int counter=0; 	  
			  									   for(s =i; s>=1; s--)
			  									   {
			  										   if(i%s==0)
			  										   {
			  											   counter = counter + 1;
			  										   }
			  									   }
			  									   if (counter ==2)
			  									   {
			  										   flag = true;
			  									   }	
			  								   	}	return flag;
			  								   }
		});

		System.out.println("########$$$$$$");
		System.out.println(primes.take(5));
		// Transformation_2 -Sum
		@SuppressWarnings("serial")
		int totalLength = primes.reduce(new Function2<Integer, Integer, Integer>() {
			  public Integer call(Integer a, Integer b) { return a + b; }
		});

		System.out.println(totalLength);
	}

	}
